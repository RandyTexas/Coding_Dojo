SELECT * FROM names

-- INSERT INTO names(name) VALUES("Randall");
SET SQL_SAFE_UPDATES = 0;


-- UPDATE names
-- SET name = "Terry"

-- UPDATE names
-- SET name = "Randall"
-- WHERE id =1;


// neil
var countN = 9;
var countElement = document.querySelector(".neil")

function add1(){
    countN++;
    countElement.innerText = countN + " like(s)"
    console.log(countN)
}

// nichole
var countn = 12;
var countElement1 = document.querySelector(".nichole")

function add2(){
    countn++;
    countElement1.innerText = countn + " like(s)"
    console.log(countn)
}

// jim
var countj = 9;
var countElement2 = document.querySelector(".jim")

function add3(){
    countj++;
    countElement2.innerText = countj + " like(s)"
    console.log(countj)
}






function nameChange(){
    let h1 = document.querySelector("h1");
    h1.innerText = "Randall Wolfe";
}

function hi (close) {
    console.log("Hello")
    let line = document.querySelector(`#${close}`)
    line.remove();
}  





// Keep count of the likes- what would this variable do?
var likeCount = 0;
// It will increment the number of likes to the variable - what would be the function of this code block?
function increaseLikes() {
    // To increase the varaiable by 1  example x = x + 1 - what is this sort operation for?
    likeCount = likeCount + 1;
}

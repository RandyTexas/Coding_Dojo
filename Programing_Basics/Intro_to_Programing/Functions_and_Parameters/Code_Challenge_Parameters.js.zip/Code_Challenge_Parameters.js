function GreetSomeOne(Name,Date,Time){
    if(Name == "Count Dooku"){
        console.log("I'm comming for you " + "Dooku ");
    } else{
        console.log("Good Day today is isnt it " + Name + "? " + "Todays is " + Date + "and the time is " + Time);
    }
}
GreetSomeOne("Randall", "10/15/2023 ", "1:00PM")
GreetSomeOne("Count Dooku", "10/16/2023 ", "1:00AM")
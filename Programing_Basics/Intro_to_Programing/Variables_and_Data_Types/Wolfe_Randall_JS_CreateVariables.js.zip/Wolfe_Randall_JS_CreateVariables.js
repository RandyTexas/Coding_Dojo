
// variable for requirments to enter ride.
var MinimumHight = 42;
var Minimumage = 10;

// variable for requirments to enter ride.
var MinimumHight =42;
var Minimumage = 10;

if(MinimumHight<=42 && Minimumage<=10){
    console.log("Get on that ride, kiddo!");
} else{
    console.log("Sorry kiddo. Maybe next year.");
}
/*
I used ChatGPT to help me figure out how to write it in JavaScripts I understood what the assignment was asking and what I needed to do!
Just I didnt know how to write this in JavaScript!
This was my Original code:

var MinimumHight =42;
var Minimumage = 10;

if(MinimumHight<=42){
    console.log("Get on that ride, kiddo!");
} else{
    console.log("Sorry kiddo. Maybe next year.");
}
if(Minimumage<=10){
    console.log("Get on that ride, kiddo!");
}else{
    console.log("Sorry kiddo. Maybe next year.")
}


I will go on Discord and ask the same question so we all can fugure it out and talk about it and understand it more!
*/ 
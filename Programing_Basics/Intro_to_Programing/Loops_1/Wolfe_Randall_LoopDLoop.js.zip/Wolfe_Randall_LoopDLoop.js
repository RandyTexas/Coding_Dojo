
// I was not sure which way is the right way I saw different ways of doing this throughout the course!
for(var Miles = 0; Miles <= 6; Miles = Miles + 2 );

// Im not sure which way to write it or not or if it made a difference?
for(var Miles = 0; Miles <= 6; Miles += 2 );

// Ninja Bonus

var Speed = 5.5
// When counting from 0-1 it means that is one finished mile and from 1-2 is two finish mile and keeping count of every 2 mile mark
for(Miles = 0; Miles <= 5; Miles+=2){
    // Setting condition for speed
    if(Speed >= 5.5);
    console.log("Have some Candy! Keep up the Good Work!");
}